package org.intellij.sdk.kotlin

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OnnxValue
import ai.onnxruntime.OrtEnvironment

import com.genesys.roberta.tokenizer.RobertaTokenizer
import com.genesys.roberta.tokenizer.RobertaTokenizerResources

import com.intellij.openapi.actionSystem.AnAction
import com.intellij.openapi.actionSystem.AnActionEvent
import com.intellij.openapi.application.ApplicationManager
import com.intellij.openapi.roots.ProjectRootManager
import com.intellij.openapi.vfs.VfsUtil

import com.intellij.psi.PsiComment
import com.intellij.psi.PsiManager
import com.intellij.psi.util.PsiTreeUtil

import io.kinference.ort.ORTEngine
import io.kinference.ort.model.ORTModel
import io.kinference.ort.data.utils.createORTData
import io.kinference.ort.ORTData
import kotlinx.coroutines.runBlocking

import kotlinx.coroutines.*
import kotlin.math.exp

class AccessKotlinFilesAction : AnAction("Access Kotlin Files") {
    private val pluginScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
//    private val stopWords = setOf("a", "an", "the", "is", "in", "at", "which", "on", "for", "with", "without", "under", "to", "from", "by", "and", "or", "but", "so", "if", "then", "else", "when")
    private var clsToken: Long = 0
    private var sepToken: Long = 0
    private var model: ORTModel? = null
    private var myTokenizer: RobertaTokenizer? = null

    override fun actionPerformed(e: AnActionEvent) {
        val env: OrtEnvironment = OrtEnvironment.getEnvironment()
        val model1 = env.createSession("/data/Soheil-data/Downloads/intellij-sdk-code-samples-main/kotlin_demo/roberta-sequence-classification-9.onnx")

        // Get the current project from the event
        val project = e.project ?: return
        val projectPath = project.basePath ?: return


        // Initialize model and tokenizer
        initModel(projectPath)
        initTokenizer(projectPath)

        pluginScope.launch {
            // Suspend until the model and tokenizer are loaded
            while (model == null || myTokenizer == null) {
                delay(1000)
                // Wait for 100ms before checking again
            }
            ApplicationManager.getApplication().invokeLater {
                ApplicationManager.getApplication().runReadAction{


                    // Get an instance of PsiManager for the project
                    val psiManager = PsiManager.getInstance(project)

                    // Get all source roots from the project
                    val virtualFiles = ProjectRootManager.getInstance(project).contentSourceRoots

                    // Iterate over each root
                    virtualFiles.forEach { root ->
                        VfsUtil.iterateChildrenRecursively(root, null) { virtualFile ->
                            if (virtualFile.extension == "kt") {
                                val psiFile = psiManager.findFile(virtualFile)

                                // Extract comments from the PsiFile
                                if (psiFile != null) {
                                    val comments = PsiTreeUtil.findChildrenOfType(psiFile, PsiComment::class.java)

                                    comments.forEach { comment ->
                                        val sentimentTensor: OnnxTensor
                                        var output: Map<String, ORTData<*>?>? = null

                                        // Get the text of the comment
                                        val inputIds = myTokenizer?.tokenize(comment.text.lowercase())
                                        println(inputIds?.joinToString())

                                        // modify Encoded Ids according to the model requirement
                                        // from [input_ids] to [[input_ids]]
                                        val newInputIds = Array(1) { inputIds?.let { it1 -> LongArray(it1.size) } }
                                        if (inputIds != null) {
                                            System.arraycopy(inputIds, 0, newInputIds[0], 0, inputIds.size)
                                        }

                                        val idsTensor = OnnxTensor.createTensor(env, newInputIds)
                                        val finalIds = createORTData("input", idsTensor)

                                        //Run inference with the model

                                        while (output == null) {
                                            ApplicationManager.getApplication().executeOnPooledThread {
                                                runBlocking {
                                                    output = model?.predict(listOf(finalIds))
                                                }
                                            }
                                        }
                                        val output1 = model1.run(mapOf("input" to idsTensor))
                                        val output1sentimentTensor = output1["output"]
                                        val sentiment1: OnnxValue = output1sentimentTensor.get()
                                        val sentimentList1 = sentiment1.value as Array<FloatArray>

                                        println("Output: ${output?.get("output")?.data}")

                                        // Find the index of the maximum value in scores
                                        sentimentTensor = output?.get("output")?.data as OnnxTensor
                                        val sentiment: Array<FloatArray> = (sentimentTensor.value as Array<FloatArray>?)!!

                                        println("Sentiment: ${sentiment.get(0)}")

                                        val sentimentList: List<Float>  = sentiment.get(0).toList()
                                        println("Sentiment List: $sentimentList")

                                        val probabilities = softMax(sentimentList)
                                        println("Probabilities: $probabilities")
                                    }
                                }
                            }
                            true  // Continue iterating
                        }
                    }
                }
            }
        }
    }

    private fun initModel(path: String) {
        pluginScope.launch{
            model = ORTEngine.loadModel(path + "/roberta-sequence-classification-9.onnx")
        }
        println("Model loaded")
    }
    private fun initTokenizer(path: String) {

        val tokenizerResource = RobertaTokenizerResources("/data/Soheil-data/IntelljProjects/Kotlin-comments-sentiment-analysis/src/main/resources/")
        myTokenizer = RobertaTokenizer(tokenizerResource)
        clsToken = myTokenizer!!.getClsToken();
        sepToken = myTokenizer!!.getSepToken();
        println("Tokenizer loaded")
    }

    private fun sigmoid(x: Float): Float {
        return (1.0 / (1.0 + Math.exp(-x.toDouble()))).toFloat()
    }

    private fun softMax(x: List<Float>): List<Float>{
        val odds = x.map { exp(it.toDouble())}
        val sum = odds.sum()
        return odds.map { it.toFloat() / sum.toFloat() }
    }

}
